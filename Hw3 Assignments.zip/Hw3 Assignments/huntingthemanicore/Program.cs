﻿namespace huntingthemanicore
{
    public class Program
    {
        static void Main(string[] args)
        {
            manigame amani = new manigame();
            amani.huntmani();


        }
    }
}
